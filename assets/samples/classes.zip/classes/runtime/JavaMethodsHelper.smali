.class public Lruntime/JavaMethodsHelper;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lruntime/JavaMethodsHelper$MapHelper;,
        Lruntime/JavaMethodsHelper$StringsHelper;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.class public Lruntime/ContextSaver;
.super Ljava/lang/Object;


# static fields
.field private static final contextLock:Ljava/util/concurrent/locks/ReentrantLock;

.field private static final contextSetCallbackList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lruntime/ContextSetCallback;",
            ">;"
        }
    .end annotation
.end field

.field private static volatile sContext:Landroid/content/Context;


# direct methods
.method static bridge synthetic -$$Nest$sfgetcontextLock()Ljava/util/concurrent/locks/ReentrantLock;
    .locals 1

    sget-object v0, Lruntime/ContextSaver;->contextLock:Ljava/util/concurrent/locks/ReentrantLock;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$sfgetcontextSetCallbackList()Ljava/util/List;
    .locals 1

    sget-object v0, Lruntime/ContextSaver;->contextSetCallbackList:Ljava/util/List;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$sfgetsContext()Landroid/content/Context;
    .locals 1

    sget-object v0, Lruntime/ContextSaver;->sContext:Landroid/content/Context;

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Lruntime/ContextSaver;->contextSetCallbackList:Ljava/util/List;

    new-instance v0, Ljava/util/concurrent/locks/ReentrantLock;

    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    sput-object v0, Lruntime/ContextSaver;->contextLock:Ljava/util/concurrent/locks/ReentrantLock;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static registerForContextSet(Lruntime/ContextSetCallback;)V
    .locals 2

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lruntime/ContextSaver$1;

    invoke-direct {v1, p0}, Lruntime/ContextSaver$1;-><init>(Lruntime/ContextSetCallback;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method private static clearContextSetCallbackList()V
    .locals 2

    sget-object v0, Lruntime/ContextSaver;->contextSetCallbackList:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lruntime/ContextSetCallback;

    invoke-interface {v1}, Lruntime/ContextSetCallback;->onContextSet()V

    goto :goto_0

    :cond_0
    sget-object v0, Lruntime/ContextSaver;->contextSetCallbackList:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    return-void
.end method

.method public static get()Landroid/content/Context;
    .locals 1

    sget-object v0, Lruntime/ContextSaver;->sContext:Landroid/content/Context;

    return-object v0
.end method

.method public static set(Landroid/content/Context;)V
    .locals 1

    sget-object v0, Lruntime/ContextSaver;->contextLock:Ljava/util/concurrent/locks/ReentrantLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    sget-object v0, Lruntime/ContextSaver;->sContext:Landroid/content/Context;

    if-eqz v0, :cond_0

    sget-object p0, Lruntime/ContextSaver;->contextLock:Ljava/util/concurrent/locks/ReentrantLock;

    invoke-virtual {p0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    return-void

    :cond_0
    if-nez p0, :cond_1

    sget-object p0, Lruntime/ContextSaver;->contextLock:Ljava/util/concurrent/locks/ReentrantLock;

    invoke-virtual {p0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    return-void

    :cond_1
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    if-nez v0, :cond_2

    sput-object p0, Lruntime/ContextSaver;->sContext:Landroid/content/Context;

    goto :goto_0

    :cond_2
    sput-object v0, Lruntime/ContextSaver;->sContext:Landroid/content/Context;

    :goto_0
    sget-object p0, Lruntime/ContextSaver;->contextLock:Ljava/util/concurrent/locks/ReentrantLock;

    invoke-virtual {p0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    invoke-static {}, Lruntime/ContextSaver;->clearContextSetCallbackList()V

    return-void
.end method

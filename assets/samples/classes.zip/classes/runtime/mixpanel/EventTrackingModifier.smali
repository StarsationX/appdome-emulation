.class public interface abstract Lruntime/mixpanel/EventTrackingModifier;
.super Ljava/lang/Object;


# virtual methods
.method public abstract updateEventDetails(Lorg/json/JSONObject;)Lorg/json/JSONObject;
.end method

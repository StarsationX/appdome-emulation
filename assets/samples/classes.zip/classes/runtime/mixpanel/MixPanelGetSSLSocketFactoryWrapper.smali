.class public Lruntime/mixpanel/MixPanelGetSSLSocketFactoryWrapper;
.super Ljava/lang/Object;


# static fields
.field private static sslSocketFactory:Ljavax/net/ssl/SSLSocketFactory;

.field private static final sslSocketFactoryLock:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/4 v0, 0x0

    sput-object v0, Lruntime/mixpanel/MixPanelGetSSLSocketFactoryWrapper;->sslSocketFactory:Ljavax/net/ssl/SSLSocketFactory;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lruntime/mixpanel/MixPanelGetSSLSocketFactoryWrapper;->sslSocketFactoryLock:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static httpsURLConnectionSetSSLSocketFactory(Ljavax/net/ssl/HttpsURLConnection;Ljavax/net/ssl/SSLSocketFactory;)V
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0}, Ljavax/net/ssl/HttpsURLConnection;->getURL()Ljava/net/URL;

    move-result-object v0

    invoke-virtual {v0}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lruntime/mixpanel/MixPanelGetSSLSocketFactoryWrapper;->getSslSocketFactoryForHost(Ljava/lang/String;)Ljavax/net/ssl/SSLSocketFactory;

    move-result-object v0

    if-nez v0, :cond_0

    invoke-virtual {p0, p1}, Ljavax/net/ssl/HttpsURLConnection;->setSSLSocketFactory(Ljavax/net/ssl/SSLSocketFactory;)V

    return-void

    :cond_0
    invoke-virtual {p0, v0}, Ljavax/net/ssl/HttpsURLConnection;->setSSLSocketFactory(Ljavax/net/ssl/SSLSocketFactory;)V

    return-void
.end method

.method private static getSslSocketFactoryForHost(Ljava/lang/String;)Ljavax/net/ssl/SSLSocketFactory;
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const-string v0, "api.mixpanel.com"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    const-string v0, "decide.mixpanel.com"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    sget-object p0, Lruntime/mixpanel/MixPanelGetSSLSocketFactoryWrapper;->sslSocketFactoryLock:Ljava/lang/Object;

    monitor-enter p0

    :try_start_0
    sget-object v0, Lruntime/mixpanel/MixPanelGetSSLSocketFactoryWrapper;->sslSocketFactory:Ljavax/net/ssl/SSLSocketFactory;

    if-eqz v0, :cond_1

    sget-object v0, Lruntime/mixpanel/MixPanelGetSSLSocketFactoryWrapper;->sslSocketFactory:Ljavax/net/ssl/SSLSocketFactory;

    monitor-exit p0

    return-object v0

    :cond_1
    invoke-static {}, Lruntime/ADUtils/JavaCertificateKeyStoreCreator;->getSSLSocketFactoryForServer()Ljavax/net/ssl/SSLSocketFactory;

    move-result-object v0

    sput-object v0, Lruntime/mixpanel/MixPanelGetSSLSocketFactoryWrapper;->sslSocketFactory:Ljavax/net/ssl/SSLSocketFactory;

    sget-object v0, Lruntime/mixpanel/MixPanelGetSSLSocketFactoryWrapper;->sslSocketFactory:Ljavax/net/ssl/SSLSocketFactory;

    if-eqz v0, :cond_2

    sget-object v0, Lruntime/mixpanel/MixPanelGetSSLSocketFactoryWrapper;->sslSocketFactory:Ljavax/net/ssl/SSLSocketFactory;

    monitor-exit p0

    return-object v0

    :cond_2
    const-string v0, "could not initialize MixPanel secure connection in order to load MixpanelAPI"

    invoke-static {v0}, Lruntime/Log;->support(Ljava/lang/String;)V

    new-instance v0, Ljava/io/IOException;

    const-string v1, "could not initialize MixPanel secure connection"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :catchall_0
    move-exception v0

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0
.end method

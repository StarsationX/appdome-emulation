.class public Lruntime/mixpanel/EventTracking;
.super Ljava/lang/Object;


# static fields
.field private static context:Landroid/content/Context;

.field private static final eventTrackingModifierSet:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Lruntime/mixpanel/EventTrackingModifier;",
            ">;"
        }
    .end annotation
.end field

.field private static mixpanelAPIInstance:Lmx_com/mixpanel/android/mpmetrics/MixpanelAPI;

.field private static serverAppToken:Ljava/lang/String;

.field private static serverFusedAppToken:Ljava/lang/String;

.field private static serverName:Ljava/lang/String;

.field private static trackingIdentity:Ljava/lang/String;

.field private static trackingToken:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/4 v0, 0x0

    sput-object v0, Lruntime/mixpanel/EventTracking;->trackingIdentity:Ljava/lang/String;

    sput-object v0, Lruntime/mixpanel/EventTracking;->trackingToken:Ljava/lang/String;

    sput-object v0, Lruntime/mixpanel/EventTracking;->serverAppToken:Ljava/lang/String;

    sput-object v0, Lruntime/mixpanel/EventTracking;->serverName:Ljava/lang/String;

    sput-object v0, Lruntime/mixpanel/EventTracking;->serverFusedAppToken:Ljava/lang/String;

    sput-object v0, Lruntime/mixpanel/EventTracking;->mixpanelAPIInstance:Lmx_com/mixpanel/android/mpmetrics/MixpanelAPI;

    sput-object v0, Lruntime/mixpanel/EventTracking;->context:Landroid/content/Context;

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    sput-object v0, Lruntime/mixpanel/EventTracking;->eventTrackingModifierSet:Ljava/util/Set;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static isAppForeground()Ljava/lang/Boolean;
    .locals 6

    invoke-static {}, Lruntime/ContextSaver;->get()Landroid/content/Context;

    move-result-object v0

    const-string v1, "VSE"

    invoke-static/range {v1 .. v1}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/KeyguardManager;

    invoke-virtual {v1}, Landroid/app/KeyguardManager;->isKeyguardLocked()Z

    move-result v1

    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    if-eqz v1, :cond_0

    return-object v3

    :cond_0
    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v1

    const-string v4, "VSY"

    invoke-static/range {v4 .. v4}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/ActivityManager;

    invoke-virtual {v0}, Landroid/app/ActivityManager;->getRunningAppProcesses()Ljava/util/List;

    move-result-object v0

    if-eqz v0, :cond_4

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/app/ActivityManager$RunningAppProcessInfo;

    iget v5, v4, Landroid/app/ActivityManager$RunningAppProcessInfo;->pid:I

    if-ne v5, v1, :cond_2

    iget v0, v4, Landroid/app/ActivityManager$RunningAppProcessInfo;->importance:I

    const/16 v1, 0x64

    if-ne v0, v1, :cond_1

    const/4 v2, 0x1

    :cond_1
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    :cond_2
    goto :goto_0

    :cond_3
    return-object v3

    :cond_4
    return-object v3
.end method

.method private static sendTrackingEventWithJsonString(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    invoke-static {p0, v0}, Lruntime/mixpanel/EventTracking;->sendTrackingEventWithProperties(Ljava/lang/String;Lorg/json/JSONObject;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p0

    :goto_0
    return-void
.end method

.method public static addEventTrackingDetailModifier(Lruntime/mixpanel/EventTrackingModifier;)V
    .locals 2

    if-nez p0, :cond_0

    return-void

    :cond_0
    sget-object v0, Lruntime/mixpanel/EventTracking;->eventTrackingModifierSet:Ljava/util/Set;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lruntime/mixpanel/EventTracking;->eventTrackingModifierSet:Ljava/util/Set;

    invoke-interface {v1, p0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method private static getAdconfigAnalyticsEndpointUrlKeyString()Ljava/lang/String;
    .locals 1

    const-string v0, "VSz"

    invoke-static/range {v0 .. v0}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static flush()V
    .locals 1

    sget-object v0, Lruntime/mixpanel/EventTracking;->mixpanelAPIInstance:Lmx_com/mixpanel/android/mpmetrics/MixpanelAPI;

    if-nez v0, :cond_0

    return-void

    :cond_0
    sget-object v0, Lruntime/mixpanel/EventTracking;->mixpanelAPIInstance:Lmx_com/mixpanel/android/mpmetrics/MixpanelAPI;

    invoke-virtual {v0}, Lmx_com/mixpanel/android/mpmetrics/MixpanelAPI;->flush()V

    return-void
.end method

.method private static identify(Ljava/lang/String;)V
    .locals 1

    sget-object v0, Lruntime/mixpanel/EventTracking;->mixpanelAPIInstance:Lmx_com/mixpanel/android/mpmetrics/MixpanelAPI;

    if-nez v0, :cond_0

    return-void

    :cond_0
    sget-object v0, Lruntime/mixpanel/EventTracking;->mixpanelAPIInstance:Lmx_com/mixpanel/android/mpmetrics/MixpanelAPI;

    invoke-virtual {v0, p0}, Lmx_com/mixpanel/android/mpmetrics/MixpanelAPI;->identify(Ljava/lang/String;)V

    return-void
.end method

.method private static init(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    sput-object p0, Lruntime/mixpanel/EventTracking;->trackingIdentity:Ljava/lang/String;

    sput-object p1, Lruntime/mixpanel/EventTracking;->trackingToken:Ljava/lang/String;

    sput-object p2, Lruntime/mixpanel/EventTracking;->serverAppToken:Ljava/lang/String;

    sput-object p3, Lruntime/mixpanel/EventTracking;->serverName:Ljava/lang/String;

    sput-object p4, Lruntime/mixpanel/EventTracking;->serverFusedAppToken:Ljava/lang/String;

    invoke-static {}, Lruntime/ContextSaver;->get()Landroid/content/Context;

    move-result-object p0

    sput-object p0, Lruntime/mixpanel/EventTracking;->context:Landroid/content/Context;

    invoke-static {}, Lruntime/ADUtils/JavaCertificateKeyStoreCreator;->getSSLSocketFactoryForServer()Ljavax/net/ssl/SSLSocketFactory;

    move-result-object p0

    if-nez p0, :cond_0

    const-string p0, "could not initialize MixPanel secure connection in order to load MixpanelAPI"

    invoke-static {p0}, Lruntime/Log;->support(Ljava/lang/String;)V

    return-void

    :cond_0
    sget-object p2, Lruntime/mixpanel/EventTracking;->context:Landroid/content/Context;

    invoke-static {p2}, Lmx_com/mixpanel/android/mpmetrics/MPConfig;->getInstance(Landroid/content/Context;)Lmx_com/mixpanel/android/mpmetrics/MPConfig;

    move-result-object p2

    invoke-virtual {p2, p0}, Lmx_com/mixpanel/android/mpmetrics/MPConfig;->setSSLSocketFactory(Ljavax/net/ssl/SSLSocketFactory;)V

    invoke-static {}, Lruntime/mixpanel/EventTracking;->getAdconfigAnalyticsEndpointUrlKeyString()Ljava/lang/String;

    move-result-object p0

    const-string p3, "VS5"

    invoke-static/range {p3 .. p3}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    invoke-static {p0, p3}, Lruntime/ADConfig/ADConfig;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lruntime/StringUtils;->isNullOrEmpty(Ljava/lang/String;)Z

    move-result p3

    if-nez p3, :cond_1

    invoke-virtual {p2, p0}, Lmx_com/mixpanel/android/mpmetrics/MPConfig;->setServerURL(Ljava/lang/String;)V

    :cond_1
    sget-object p0, Lruntime/mixpanel/EventTracking;->context:Landroid/content/Context;

    const/4 p2, 0x0

    invoke-static {p0, p1, p2}, Lmx_com/mixpanel/android/mpmetrics/MixpanelAPI;->getInstance(Landroid/content/Context;Ljava/lang/String;Z)Lmx_com/mixpanel/android/mpmetrics/MixpanelAPI;

    move-result-object p0

    sput-object p0, Lruntime/mixpanel/EventTracking;->mixpanelAPIInstance:Lmx_com/mixpanel/android/mpmetrics/MixpanelAPI;

    sget-object p0, Lruntime/mixpanel/EventTracking;->context:Landroid/content/Context;

    invoke-static {p0}, Lruntime/events/Orientation;->register(Landroid/content/Context;)V

    return-void
.end method

.method private static sendTrackingEventWithProperties(Ljava/lang/String;Lorg/json/JSONObject;)V
    .locals 3

    sget-object v0, Lruntime/mixpanel/EventTracking;->trackingIdentity:Ljava/lang/String;

    if-eqz v0, :cond_5

    sget-object v0, Lruntime/mixpanel/EventTracking;->trackingToken:Ljava/lang/String;

    if-nez v0, :cond_0

    goto/16 :goto_3

    :cond_0
    :try_start_0
    sget-object v0, Lruntime/mixpanel/EventTracking;->trackingIdentity:Ljava/lang/String;

    invoke-static {v0}, Lruntime/mixpanel/EventTracking;->identify(Ljava/lang/String;)V

    if-nez p1, :cond_1

    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    :cond_1
    const-string v0, "deviceID"

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_2

    const-string v1, "no data"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    :cond_2
    invoke-static {}, Lruntime/DeviceUtils;->getDeviceIdAndroidApi()Ljava/lang/String;

    move-result-object v0

    const-string v1, "deviceID"

    invoke-virtual {p1, v1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    :cond_3
    :try_start_1
    const-string v0, "Application"

    sget-object v1, Lruntime/mixpanel/EventTracking;->context:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "Identity"

    sget-object v1, Lruntime/mixpanel/EventTracking;->trackingIdentity:Ljava/lang/String;

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "Appdome fusion app token"

    sget-object v1, Lruntime/mixpanel/EventTracking;->serverAppToken:Ljava/lang/String;

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "Appdome fusion server name"

    sget-object v1, Lruntime/mixpanel/EventTracking;->serverName:Ljava/lang/String;

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "Appdome fusion fused app token"

    sget-object v1, Lruntime/mixpanel/EventTracking;->serverFusedAppToken:Ljava/lang/String;

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "isRunningInForeground"

    invoke-static {}, Lruntime/mixpanel/EventTracking;->isAppForeground()Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Boolean;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    sget-object v0, Lruntime/mixpanel/EventTracking;->eventTrackingModifierSet:Ljava/util/Set;

    monitor-enter v0
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :try_start_2
    sget-object v1, Lruntime/mixpanel/EventTracking;->eventTrackingModifierSet:Ljava/util/Set;

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lruntime/mixpanel/EventTrackingModifier;

    invoke-interface {v2, p1}, Lruntime/mixpanel/EventTrackingModifier;->updateEventDetails(Lorg/json/JSONObject;)Lorg/json/JSONObject;

    goto :goto_0

    :cond_4
    monitor-exit v0

    goto :goto_1

    :catchall_0
    move-exception v1

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    throw v1
    :try_end_3
    .catch Lorg/json/JSONException; {:try_start_3 .. :try_end_3} :catch_0
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    :catch_0
    move-exception v0

    :goto_1
    :try_start_4
    invoke-static {p0, p1}, Lruntime/mixpanel/EventTracking;->track(Ljava/lang/String;Lorg/json/JSONObject;)V

    invoke-static {}, Lruntime/mixpanel/EventTracking;->flush()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1

    goto :goto_2

    :catch_1
    move-exception p0

    const/4 p1, 0x0

    invoke-static {p0, p1}, Lruntime/Reflections;->handleReflectionException(Ljava/lang/Exception;Z)V

    :goto_2
    return-void

    :cond_5
    :goto_3
    return-void
.end method

.method private static track(Ljava/lang/String;Lorg/json/JSONObject;)V
    .locals 1

    sget-object v0, Lruntime/mixpanel/EventTracking;->mixpanelAPIInstance:Lmx_com/mixpanel/android/mpmetrics/MixpanelAPI;

    if-nez v0, :cond_0

    return-void

    :cond_0
    sget-object v0, Lruntime/mixpanel/EventTracking;->mixpanelAPIInstance:Lmx_com/mixpanel/android/mpmetrics/MixpanelAPI;

    invoke-virtual {v0, p0, p1}, Lmx_com/mixpanel/android/mpmetrics/MixpanelAPI;->track(Ljava/lang/String;Lorg/json/JSONObject;)V

    return-void
.end method

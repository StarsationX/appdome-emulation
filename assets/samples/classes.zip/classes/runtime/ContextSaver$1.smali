.class Lruntime/ContextSaver$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lruntime/ContextSaver;->registerForContextSet(Lruntime/ContextSetCallback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$contextSetCallback:Lruntime/ContextSetCallback;


# direct methods
.method constructor <init>(Lruntime/ContextSetCallback;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    iput-object p1, p0, Lruntime/ContextSaver$1;->val$contextSetCallback:Lruntime/ContextSetCallback;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    iget-object v0, p0, Lruntime/ContextSaver$1;->val$contextSetCallback:Lruntime/ContextSetCallback;

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-static {}, Lruntime/ContextSaver;->-$$Nest$sfgetcontextLock()Ljava/util/concurrent/locks/ReentrantLock;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    invoke-static {}, Lruntime/ContextSaver;->-$$Nest$sfgetsContext()Landroid/content/Context;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-static {}, Lruntime/ContextSaver;->-$$Nest$sfgetcontextLock()Ljava/util/concurrent/locks/ReentrantLock;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    iget-object v0, p0, Lruntime/ContextSaver$1;->val$contextSetCallback:Lruntime/ContextSetCallback;

    invoke-interface {v0}, Lruntime/ContextSetCallback;->onContextSet()V

    return-void

    :cond_1
    invoke-static {}, Lruntime/ContextSaver;->-$$Nest$sfgetcontextSetCallbackList()Ljava/util/List;

    move-result-object v0

    iget-object v1, p0, Lruntime/ContextSaver$1;->val$contextSetCallback:Lruntime/ContextSetCallback;

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-static {}, Lruntime/ContextSaver;->-$$Nest$sfgetcontextLock()Ljava/util/concurrent/locks/ReentrantLock;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    return-void
.end method

.class public Lruntime/javaSignal/JavaSignal;
.super Ljava/lang/Object;


# static fields
.field private static final ADExceptionHandler:Ljava/lang/Thread$UncaughtExceptionHandler;

.field private static originalExceptionHandler:Ljava/lang/Thread$UncaughtExceptionHandler;


# direct methods
.method static bridge synthetic -$$Nest$sfgetoriginalExceptionHandler()Ljava/lang/Thread$UncaughtExceptionHandler;
    .locals 1

    sget-object v0, Lruntime/javaSignal/JavaSignal;->originalExceptionHandler:Ljava/lang/Thread$UncaughtExceptionHandler;

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lruntime/javaSignal/JavaSignal$1;

    invoke-direct {v0}, Lruntime/javaSignal/JavaSignal$1;-><init>()V

    sput-object v0, Lruntime/javaSignal/JavaSignal;->ADExceptionHandler:Ljava/lang/Thread$UncaughtExceptionHandler;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static setExceptionHandler()V
    .locals 1

    invoke-static {}, Ljava/lang/Thread;->getDefaultUncaughtExceptionHandler()Ljava/lang/Thread$UncaughtExceptionHandler;

    move-result-object v0

    sput-object v0, Lruntime/javaSignal/JavaSignal;->originalExceptionHandler:Ljava/lang/Thread$UncaughtExceptionHandler;

    sget-object v0, Lruntime/javaSignal/JavaSignal;->ADExceptionHandler:Ljava/lang/Thread$UncaughtExceptionHandler;

    invoke-static {v0}, Ljava/lang/Thread;->setDefaultUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    return-void
.end method

.method public static getStoredExceptionHandler()Ljava/lang/Thread$UncaughtExceptionHandler;
    .locals 1

    sget-object v0, Lruntime/javaSignal/JavaSignal;->originalExceptionHandler:Ljava/lang/Thread$UncaughtExceptionHandler;

    return-object v0
.end method

.method private static final TAG()Ljava/lang/String;
    .locals 1

    const-class v0, Lruntime/javaSignal/JavaSignal;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static registerExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V
    .locals 0

    sput-object p0, Lruntime/javaSignal/JavaSignal;->originalExceptionHandler:Ljava/lang/Thread$UncaughtExceptionHandler;

    return-void
.end method

.class public Lruntime/loading/InjectedActivity;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lruntime/loading/InjectedActivity$MessageOutput;
    }
.end annotation


# static fields
.field private static final a1b2c3d4e5f6g7h8i9j0k1:Ljava/util/Stack;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Stack<",
            "Landroid/widget/Toast;",
            ">;"
        }
    .end annotation
.end field

.field private static g1h2i3j4k5l6m7n8o9p0:Z = false

.field private static final l1m2n3o4p5q6r7s8t9u0:I = 0xfa0

.field private static q1r2s3t4u5v6w7x8y9z0:Landroid/app/Activity; = null

.field private static final v1w2x3y4z5a6b7c8d9e0:I = 0x14

.field private static w1x2y3z4a5b6c7d8e9f0:Lruntime/loading/InjectedActivity$MessageOutput;


# direct methods
.method static bridge synthetic -$$Nest$sfgetw1x2y3z4a5b6c7d8e9f0()Lruntime/loading/InjectedActivity$MessageOutput;
    .locals 1

    sget-object v0, Lruntime/loading/InjectedActivity;->w1x2y3z4a5b6c7d8e9f0:Lruntime/loading/InjectedActivity$MessageOutput;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$smhandleExitToast(Lruntime/loading/InjectedActivity$MessageOutput;)V
    .locals 0

    invoke-static {p0}, Lruntime/loading/InjectedActivity;->handleExitToast(Lruntime/loading/InjectedActivity$MessageOutput;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$smdie(Landroid/content/Context;Ljava/lang/Boolean;)V
    .locals 0

    invoke-static {p0, p1}, Lruntime/loading/InjectedActivity;->die(Landroid/content/Context;Ljava/lang/Boolean;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$sfgetg1h2i3j4k5l6m7n8o9p0()Z
    .locals 1

    sget-boolean v0, Lruntime/loading/InjectedActivity;->g1h2i3j4k5l6m7n8o9p0:Z

    return v0
.end method

.method static bridge synthetic -$$Nest$sfgeta1b2c3d4e5f6g7h8i9j0k1()Ljava/util/Stack;
    .locals 1

    sget-object v0, Lruntime/loading/InjectedActivity;->a1b2c3d4e5f6g7h8i9j0k1:Ljava/util/Stack;

    return-object v0
.end method

.method static bridge synthetic -$$Nest$smshowToast(Lruntime/loading/InjectedActivity$MessageOutput;)Landroid/widget/Toast;
    .locals 0

    invoke-static {p0}, Lruntime/loading/InjectedActivity;->showToast(Lruntime/loading/InjectedActivity$MessageOutput;)Landroid/widget/Toast;

    move-result-object p0

    return-object p0
.end method

.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lruntime/loading/InjectedActivity$1;

    invoke-direct {v0}, Lruntime/loading/InjectedActivity$1;-><init>()V

    invoke-static {v0}, Lruntime/ContextSaver;->registerForContextSet(Lruntime/ContextSetCallback;)V

    const/4 v0, 0x0

    sput-object v0, Lruntime/loading/InjectedActivity;->w1x2y3z4a5b6c7d8e9f0:Lruntime/loading/InjectedActivity$MessageOutput;

    const/4 v1, 0x0

    sput-boolean v1, Lruntime/loading/InjectedActivity;->g1h2i3j4k5l6m7n8o9p0:Z

    sput-object v0, Lruntime/loading/InjectedActivity;->q1r2s3t4u5v6w7x8y9z0:Landroid/app/Activity;

    new-instance v0, Ljava/util/Stack;

    invoke-direct {v0}, Ljava/util/Stack;-><init>()V

    sput-object v0, Lruntime/loading/InjectedActivity;->a1b2c3d4e5f6g7h8i9j0k1:Ljava/util/Stack;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static ADShowPopup(Ljava/lang/String;Ljava/lang/String;ZZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 10

    new-instance v0, Lruntime/loading/InjectedActivity$MessageOutput;

    move-object v1, v0

    move-object v2, p0

    move-object v3, p1

    move v4, p2

    move v5, p3

    move v6, p4

    move-object v7, p5

    move-object/from16 v8, p6

    move-object/from16 v9, p7

    invoke-direct/range {v1 .. v9}, Lruntime/loading/InjectedActivity$MessageOutput;-><init>(Ljava/lang/String;Ljava/lang/String;ZZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    new-instance v1, Lruntime/loading/InjectedActivity$2;

    invoke-direct {v1, v0}, Lruntime/loading/InjectedActivity$2;-><init>(Lruntime/loading/InjectedActivity$MessageOutput;)V

    const-class v2, Lruntime/loading/InjectedActivity;

    monitor-enter v2

    :try_start_0
    invoke-static {}, Lruntime/ContextSaver;->get()Landroid/content/Context;

    move-result-object v3

    if-nez v3, :cond_0

    iget-boolean v3, v0, Lruntime/loading/InjectedActivity$MessageOutput;->y1z2a3b4c5d6e7f8g9h0:Z

    if-eqz v3, :cond_0

    sget-object v3, Lruntime/loading/InjectedActivity;->w1x2y3z4a5b6c7d8e9f0:Lruntime/loading/InjectedActivity$MessageOutput;

    if-nez v3, :cond_0

    sput-object v0, Lruntime/loading/InjectedActivity;->w1x2y3z4a5b6c7d8e9f0:Lruntime/loading/InjectedActivity$MessageOutput;

    monitor-exit v2

    return-void

    :cond_0
    invoke-static {v1}, Lruntime/loading/InjectedActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    monitor-exit v2

    return-void

    :catchall_0
    move-exception v0

    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0
.end method

.method public static safeDie(I)V
    .locals 4

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v1, Lruntime/loading/InjectedActivity$4;

    invoke-direct {v1}, Lruntime/loading/InjectedActivity$4;-><init>()V

    int-to-long v2, p0

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method private static showToast(Lruntime/loading/InjectedActivity$MessageOutput;)Landroid/widget/Toast;
    .locals 7

    invoke-static {}, Lruntime/ContextSaver;->get()Landroid/content/Context;

    move-result-object v0

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    iget-object v0, p0, Lruntime/loading/InjectedActivity$MessageOutput;->a1b2c3d4e5f6g7h8i9j0:Ljava/lang/String;

    iget-object v1, p0, Lruntime/loading/InjectedActivity$MessageOutput;->k1l2m3n4o5p6q7r8s9t0:Ljava/lang/String;

    iget-object v2, p0, Lruntime/loading/InjectedActivity$MessageOutput;->e1f2g3h4i5j6k7l8m9n0:Ljava/lang/String;

    invoke-static {v2}, Lruntime/StringUtils;->isNullOrEmpty(Ljava/lang/String;)Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-nez v2, :cond_2

    invoke-static {}, Lruntime/ContextSaver;->get()Landroid/content/Context;

    move-result-object v2

    iget-object v5, p0, Lruntime/loading/InjectedActivity$MessageOutput;->e1f2g3h4i5j6k7l8m9n0:Ljava/lang/String;

    invoke-static {v2, v5}, Lruntime/events/LocalizedMessages;->getLocalizedMessage(Landroid/content/Context;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_2

    aget-object v5, v2, v4

    aget-object v2, v2, v3

    invoke-static {v5}, Lruntime/StringUtils;->isNullOrEmpty(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_1

    move-object v0, v5

    :cond_1
    invoke-static {v2}, Lruntime/StringUtils;->isNullOrEmpty(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_2

    invoke-static {v1}, Lruntime/StringUtils;->isNullOrEmpty(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_2

    move-object v1, v2

    :cond_2
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v5, 0x1f

    if-ge v2, v5, :cond_3

    nop

    move v2, v3

    move v3, v4

    goto :goto_0

    :cond_3
    invoke-static {v1}, Lruntime/StringUtils;->isNullOrEmpty(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_4

    nop

    move v2, v3

    goto :goto_0

    :cond_4
    nop

    const-string v2, "ZJY"

    invoke-static/range {v2 .. v2}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v4}, Lruntime/ADConfig/ADConfig;->getBool(Ljava/lang/String;Z)Z

    move-result v3

    move v2, v3

    move v3, v4

    :goto_0
    const-string v5, "ZJs"

    invoke-static/range {v5 .. v5}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-eqz v3, :cond_6

    const-string v0, "ZJq"

    invoke-static/range {v0 .. v0}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v4}, Lruntime/ADConfig/ADConfig;->getBool(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_5

    iget-object v0, p0, Lruntime/loading/InjectedActivity$MessageOutput;->o1p2q3r4s5t6u7v8w9x0:Ljava/lang/String;

    filled-new-array {v1, v0}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v5, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    :cond_5
    iget-object v0, p0, Lruntime/loading/InjectedActivity$MessageOutput;->o1p2q3r4s5t6u7v8w9x0:Ljava/lang/String;

    filled-new-array {v0, v1}, [Ljava/lang/Object;

    move-result-object v0

    const-string v1, "ZJr"

    invoke-static/range {v1 .. v1}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    :cond_6
    iget-object v1, p0, Lruntime/loading/InjectedActivity$MessageOutput;->o1p2q3r4s5t6u7v8w9x0:Ljava/lang/String;

    filled-new-array {v0, v1}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v5, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    :goto_1
    invoke-static {}, Lruntime/loading/InjectedActivity;->p1q2r3s4t5u6v7w8x9y0()Ljava/lang/String;

    move-result-object v1

    invoke-static {}, Lruntime/loading/InjectedActivity;->getDisplayName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v1, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    invoke-static {}, Lruntime/ContextSaver;->get()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1, v0, v2}, Lruntime/events/ToastProxy;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;Z)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    iget-boolean v1, p0, Lruntime/loading/InjectedActivity$MessageOutput;->s1t2u3v4w5x6y7z8a9b0:Z

    if-eqz v1, :cond_7

    iget-object p0, p0, Lruntime/loading/InjectedActivity$MessageOutput;->u1v2w3x4y5z6a7b8c9d0:Ljava/lang/String;

    invoke-static {p0}, Lruntime/loading/InjectedActivity;->openUrl(Ljava/lang/String;)V

    :cond_7
    return-object v0
.end method

.method private static runOnUiThread(Ljava/lang/Runnable;)V
    .locals 2

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    invoke-virtual {v0, p0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public static onUserInteractionHook(Landroid/app/Activity;)V
    .locals 0

    return-void
.end method

.method public static onStopHook(Landroid/app/Activity;)V
    .locals 0

    return-void
.end method

.method private static openUrl(Ljava/lang/String;)V
    .locals 2

    new-instance v0, Landroid/content/Intent;

    const-string v1, "ZJ5"

    invoke-static/range {v1 .. v1}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/high16 v1, 0x10000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    invoke-static {}, Lruntime/ContextSaver;->get()Landroid/content/Context;

    move-result-object p0

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method private static p1q2r3s4t5u6v7w8x9y0()Ljava/lang/String;
    .locals 1

    const-string v0, "ZJE"

    invoke-static/range {v0 .. v0}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static getDisplayName()Ljava/lang/String;
    .locals 4

    invoke-static {}, Lruntime/ContextSaver;->get()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    iget v1, v0, Landroid/content/pm/ApplicationInfo;->labelRes:I

    invoke-static {}, Lruntime/ContextSaver;->get()Landroid/content/Context;

    move-result-object v2

    if-nez v1, :cond_3

    iget-object v3, v0, Landroid/content/pm/ApplicationInfo;->nonLocalizedLabel:Ljava/lang/CharSequence;

    if-nez v3, :cond_3

    :try_start_0
    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/high16 v3, 0x10000

    invoke-virtual {v1, v0, v3}, Landroid/content/pm/PackageManager;->resolveActivity(Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;

    move-result-object v0

    iget-object v0, v0, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/ActivityInfo;->loadLabel(Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_0
    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-static {}, Lruntime/loading/InjectedActivity;->getCurrentActivity()Landroid/app/Activity;

    move-result-object v1

    invoke-virtual {v1}, Landroid/app/Activity;->getComponentName()Landroid/content/ComponentName;

    move-result-object v1

    const/16 v3, 0x80

    invoke-virtual {v0, v1, v3}, Landroid/content/pm/PackageManager;->getActivityInfo(Landroid/content/ComponentName;I)Landroid/content/pm/ActivityInfo;

    move-result-object v0

    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/ActivityInfo;->loadLabel(Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    :cond_1
    nop

    invoke-static {}, Lruntime/loading/InjectedActivity;->getCurrentActivity()Landroid/app/Activity;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/Activity;->getTitle()Ljava/lang/CharSequence;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_2
    const-string v0, "ZJz"

    invoke-static/range {v0 .. v0}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_3
    if-nez v1, :cond_4

    iget-object v0, v0, Landroid/content/pm/ApplicationInfo;->nonLocalizedLabel:Ljava/lang/CharSequence;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_4
    invoke-virtual {v2, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    :goto_0
    return-object v0
.end method

.method public static onCreateHook(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 0

    invoke-virtual {p0}, Landroid/app/Activity;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1}, Lruntime/loading/StaticCalls;->dynamicInit(Landroid/content/Context;)V

    sget-boolean p1, Lruntime/loading/InjectedActivity;->g1h2i3j4k5l6m7n8o9p0:Z

    if-eqz p1, :cond_0

    sput-object p0, Lruntime/loading/InjectedActivity;->q1r2s3t4u5v6w7x8y9z0:Landroid/app/Activity;

    return-void

    :cond_0
    invoke-static {p0}, Lruntime/loading/InjectedActivity;->runFirstActivityActions(Landroid/app/Activity;)V

    return-void
.end method

.method public static getCurrentActivity()Landroid/app/Activity;
    .locals 1

    sget-object v0, Lruntime/loading/InjectedActivity;->q1r2s3t4u5v6w7x8y9z0:Landroid/app/Activity;

    return-object v0
.end method

.method public static onRequestPermissionsResultHook(Landroid/app/Activity;I[Ljava/lang/String;[I)V
    .locals 0

    return-void
.end method

.method private static handleExitToast(Lruntime/loading/InjectedActivity$MessageOutput;)V
    .locals 4

    const/4 v0, 0x1

    sput-boolean v0, Lruntime/loading/InjectedActivity;->g1h2i3j4k5l6m7n8o9p0:Z

    sget-object v0, Lruntime/loading/InjectedActivity;->a1b2c3d4e5f6g7h8i9j0k1:Ljava/util/Stack;

    invoke-virtual {v0}, Ljava/util/Stack;->size()I

    nop

    nop

    :cond_0
    :goto_0
    sget-object v0, Lruntime/loading/InjectedActivity;->a1b2c3d4e5f6g7h8i9j0k1:Ljava/util/Stack;

    invoke-virtual {v0}, Ljava/util/Stack;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1

    sget-object v0, Lruntime/loading/InjectedActivity;->a1b2c3d4e5f6g7h8i9j0k1:Ljava/util/Stack;

    invoke-virtual {v0}, Ljava/util/Stack;->pop()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/widget/Toast;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/widget/Toast;->cancel()V

    goto :goto_0

    :cond_1
    invoke-static {p0}, Lruntime/loading/InjectedActivity;->showToast(Lruntime/loading/InjectedActivity$MessageOutput;)Landroid/widget/Toast;

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v1, Lruntime/loading/InjectedActivity$3;

    invoke-direct {v1, p0}, Lruntime/loading/InjectedActivity$3;-><init>(Lruntime/loading/InjectedActivity$MessageOutput;)V

    const-wide/16 v2, 0xfa0

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public static onResumeHook(Landroid/app/Activity;)V
    .locals 1

    sget-boolean v0, Lruntime/loading/InjectedActivity;->g1h2i3j4k5l6m7n8o9p0:Z

    if-eqz v0, :cond_0

    sput-object p0, Lruntime/loading/InjectedActivity;->q1r2s3t4u5v6w7x8y9z0:Landroid/app/Activity;

    return-void

    :cond_0
    invoke-static {p0}, Lruntime/loading/InjectedActivity;->runFirstActivityActions(Landroid/app/Activity;)V

    invoke-static {}, Lruntime/loading/NativeBridge;->onResumedCalled()V

    return-void
.end method

.method public static onStartHook(Landroid/app/Activity;)V
    .locals 0

    return-void
.end method

.method public static runFirstActivityActions(Landroid/app/Activity;)V
    .locals 2

    nop

    const-class v0, Lruntime/loading/InjectedActivity;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lruntime/loading/InjectedActivity;->q1r2s3t4u5v6w7x8y9z0:Landroid/app/Activity;

    sput-object p0, Lruntime/loading/InjectedActivity;->q1r2s3t4u5v6w7x8y9z0:Landroid/app/Activity;

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v1, :cond_0

    if-eqz p0, :cond_0

    invoke-static {}, Lruntime/loading/NativeBridge;->runFirstActivityActions()V

    :cond_0
    return-void

    :catchall_0
    move-exception p0

    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0
.end method

.method public static die()V
    .locals 1

    const/4 v0, 0x0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-static {v0}, Lruntime/loading/InjectedActivity;->die(Ljava/lang/Boolean;)V

    return-void
.end method

.method public static die(Landroid/content/Context;)V
    .locals 1

    const/4 v0, 0x0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-static {p0, v0}, Lruntime/loading/InjectedActivity;->die(Landroid/content/Context;Ljava/lang/Boolean;)V

    return-void
.end method

.method private static die(Landroid/content/Context;Ljava/lang/Boolean;)V
    .locals 1

    nop

    if-eqz p0, :cond_0

    instance-of v0, p0, Landroid/app/Activity;

    if-eqz v0, :cond_0

    check-cast p0, Landroid/app/Activity;

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    sget-object v0, Lruntime/loading/InjectedActivity;->q1r2s3t4u5v6w7x8y9z0:Landroid/app/Activity;

    if-eqz v0, :cond_1

    sget-object v0, Lruntime/loading/InjectedActivity;->q1r2s3t4u5v6w7x8y9z0:Landroid/app/Activity;

    if-eq v0, p0, :cond_1

    sget-object p0, Lruntime/loading/InjectedActivity;->q1r2s3t4u5v6w7x8y9z0:Landroid/app/Activity;

    :cond_1
    if-eqz p0, :cond_2

    nop

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/app/Activity;->setResult(I)V

    invoke-virtual {p0}, Landroid/app/Activity;->finishAndRemoveTask()V

    :cond_2
    invoke-static {p1}, Lruntime/loading/InjectedActivity;->die(Ljava/lang/Boolean;)V

    return-void
.end method

.method private static die(Ljava/lang/Boolean;)V
    .locals 2

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    if-eqz p0, :cond_0

    invoke-static {}, Lruntime/ContextSaver;->get()Landroid/content/Context;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const v1, 0x14008000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    :cond_0
    invoke-static {}, Lruntime/loading/NativeBridge;->killForkUtilChildProcesses()V

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result p0

    invoke-static {p0}, Landroid/os/Process;->killProcess(I)V

    return-void
.end method

.method public static onPauseHook(Landroid/app/Activity;)V
    .locals 0

    invoke-static {}, Lruntime/loading/NativeBridge;->onPausedCalled()V

    return-void
.end method

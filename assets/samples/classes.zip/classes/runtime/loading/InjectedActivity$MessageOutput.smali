.class Lruntime/loading/InjectedActivity$MessageOutput;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lruntime/loading/InjectedActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "Z4MsA1"
.end annotation


# instance fields
.field a1b2c3d4e5f6g7h8i9j0:Ljava/lang/String;

.field e1f2g3h4i5j6k7l8m9n0:Ljava/lang/String;

.field i1j2k3l4m5n6o7p8q9r0:Z

.field k1l2m3n4o5p6q7r8s9t0:Ljava/lang/String;

.field o1p2q3r4s5t6u7v8w9x0:Ljava/lang/String;

.field s1t2u3v4w5x6y7z8a9b0:Z

.field u1v2w3x4y5z6a7b8c9d0:Ljava/lang/String;

.field y1z2a3b4c5d6e7f8g9h0:Z


# direct methods
.method constructor <init>(Lruntime/loading/InjectedActivity$MessageOutput;)V
    .locals 9

    iget-object v1, p1, Lruntime/loading/InjectedActivity$MessageOutput;->a1b2c3d4e5f6g7h8i9j0:Ljava/lang/String;

    iget-object v2, p1, Lruntime/loading/InjectedActivity$MessageOutput;->k1l2m3n4o5p6q7r8s9t0:Ljava/lang/String;

    iget-boolean v3, p1, Lruntime/loading/InjectedActivity$MessageOutput;->y1z2a3b4c5d6e7f8g9h0:Z

    iget-boolean v4, p1, Lruntime/loading/InjectedActivity$MessageOutput;->i1j2k3l4m5n6o7p8q9r0:Z

    iget-boolean v5, p1, Lruntime/loading/InjectedActivity$MessageOutput;->s1t2u3v4w5x6y7z8a9b0:Z

    iget-object v6, p1, Lruntime/loading/InjectedActivity$MessageOutput;->u1v2w3x4y5z6a7b8c9d0:Ljava/lang/String;

    iget-object v7, p1, Lruntime/loading/InjectedActivity$MessageOutput;->e1f2g3h4i5j6k7l8m9n0:Ljava/lang/String;

    iget-object v8, p1, Lruntime/loading/InjectedActivity$MessageOutput;->o1p2q3r4s5t6u7v8w9x0:Ljava/lang/String;

    move-object v0, p0

    invoke-direct/range {v0 .. v8}, Lruntime/loading/InjectedActivity$MessageOutput;-><init>(Ljava/lang/String;Ljava/lang/String;ZZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method constructor <init>(Ljava/lang/String;Ljava/lang/String;ZZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lruntime/loading/InjectedActivity$MessageOutput;->a1b2c3d4e5f6g7h8i9j0:Ljava/lang/String;

    iput-object p2, p0, Lruntime/loading/InjectedActivity$MessageOutput;->k1l2m3n4o5p6q7r8s9t0:Ljava/lang/String;

    iput-boolean p3, p0, Lruntime/loading/InjectedActivity$MessageOutput;->y1z2a3b4c5d6e7f8g9h0:Z

    iput-boolean p4, p0, Lruntime/loading/InjectedActivity$MessageOutput;->i1j2k3l4m5n6o7p8q9r0:Z

    iput-boolean p5, p0, Lruntime/loading/InjectedActivity$MessageOutput;->s1t2u3v4w5x6y7z8a9b0:Z

    iput-object p6, p0, Lruntime/loading/InjectedActivity$MessageOutput;->u1v2w3x4y5z6a7b8c9d0:Ljava/lang/String;

    iput-object p7, p0, Lruntime/loading/InjectedActivity$MessageOutput;->e1f2g3h4i5j6k7l8m9n0:Ljava/lang/String;

    iput-object p8, p0, Lruntime/loading/InjectedActivity$MessageOutput;->o1p2q3r4s5t6u7v8w9x0:Ljava/lang/String;

    return-void
.end method

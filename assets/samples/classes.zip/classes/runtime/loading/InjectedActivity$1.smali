.class Lruntime/loading/InjectedActivity$1;
.super Ljava/lang/Object;

# interfaces
.implements Lruntime/ContextSetCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lruntime/loading/InjectedActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onContextSet()V
    .locals 10

    const-class v0, Lruntime/loading/InjectedActivity;

    monitor-enter v0

    :try_start_0
    invoke-static {}, Lruntime/loading/InjectedActivity;->-$$Nest$sfgetw1x2y3z4a5b6c7d8e9f0()Lruntime/loading/InjectedActivity$MessageOutput;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-static {}, Lruntime/loading/InjectedActivity;->-$$Nest$sfgetw1x2y3z4a5b6c7d8e9f0()Lruntime/loading/InjectedActivity$MessageOutput;

    move-result-object v1

    iget-object v2, v1, Lruntime/loading/InjectedActivity$MessageOutput;->a1b2c3d4e5f6g7h8i9j0:Ljava/lang/String;

    invoke-static {}, Lruntime/loading/InjectedActivity;->-$$Nest$sfgetw1x2y3z4a5b6c7d8e9f0()Lruntime/loading/InjectedActivity$MessageOutput;

    move-result-object v1

    iget-object v3, v1, Lruntime/loading/InjectedActivity$MessageOutput;->k1l2m3n4o5p6q7r8s9t0:Ljava/lang/String;

    invoke-static {}, Lruntime/loading/InjectedActivity;->-$$Nest$sfgetw1x2y3z4a5b6c7d8e9f0()Lruntime/loading/InjectedActivity$MessageOutput;

    move-result-object v1

    iget-boolean v4, v1, Lruntime/loading/InjectedActivity$MessageOutput;->y1z2a3b4c5d6e7f8g9h0:Z

    invoke-static {}, Lruntime/loading/InjectedActivity;->-$$Nest$sfgetw1x2y3z4a5b6c7d8e9f0()Lruntime/loading/InjectedActivity$MessageOutput;

    move-result-object v1

    iget-boolean v5, v1, Lruntime/loading/InjectedActivity$MessageOutput;->i1j2k3l4m5n6o7p8q9r0:Z

    invoke-static {}, Lruntime/loading/InjectedActivity;->-$$Nest$sfgetw1x2y3z4a5b6c7d8e9f0()Lruntime/loading/InjectedActivity$MessageOutput;

    move-result-object v1

    iget-boolean v6, v1, Lruntime/loading/InjectedActivity$MessageOutput;->s1t2u3v4w5x6y7z8a9b0:Z

    invoke-static {}, Lruntime/loading/InjectedActivity;->-$$Nest$sfgetw1x2y3z4a5b6c7d8e9f0()Lruntime/loading/InjectedActivity$MessageOutput;

    move-result-object v1

    iget-object v7, v1, Lruntime/loading/InjectedActivity$MessageOutput;->u1v2w3x4y5z6a7b8c9d0:Ljava/lang/String;

    invoke-static {}, Lruntime/loading/InjectedActivity;->-$$Nest$sfgetw1x2y3z4a5b6c7d8e9f0()Lruntime/loading/InjectedActivity$MessageOutput;

    move-result-object v1

    iget-object v8, v1, Lruntime/loading/InjectedActivity$MessageOutput;->e1f2g3h4i5j6k7l8m9n0:Ljava/lang/String;

    invoke-static {}, Lruntime/loading/InjectedActivity;->-$$Nest$sfgetw1x2y3z4a5b6c7d8e9f0()Lruntime/loading/InjectedActivity$MessageOutput;

    move-result-object v1

    iget-object v9, v1, Lruntime/loading/InjectedActivity$MessageOutput;->o1p2q3r4s5t6u7v8w9x0:Ljava/lang/String;

    invoke-static/range {v2 .. v9}, Lruntime/loading/InjectedActivity;->ADShowPopup(Ljava/lang/String;Ljava/lang/String;ZZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    monitor-exit v0

    return-void

    :catchall_0
    move-exception v1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1
.end method

.class public Lruntime/loading/StaticCalls;
.super Ljava/lang/Object;


# static fields
.field private static dynamicInitDone:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/4 v0, 0x0

    sput-boolean v0, Lruntime/loading/StaticCalls;->dynamicInitDone:Z

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static dynamicInit(Landroid/content/Context;)V
    .locals 1

    sget-boolean v0, Lruntime/loading/StaticCalls;->dynamicInitDone:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    sput-boolean v0, Lruntime/loading/StaticCalls;->dynamicInitDone:Z

    invoke-static {}, Lruntime/loading/NativeBridge;->registerNatives()V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lruntime/ContextSaver;->set(Landroid/content/Context;)V

    invoke-static {p0}, Lruntime/loading/NativeBridge;->setApplication(Ljava/lang/Object;)V

    invoke-static {p0}, Lruntime/loading/StaticCalls;->initPluginsDynamicInit(Landroid/content/Context;)V

    return-void
.end method

.method private static initPluginsDynamicInit(Landroid/content/Context;)V
    .locals 0

    invoke-static {}, Lruntime/javaSignal/JavaSignal;->setExceptionHandler()V

    return-void
.end method

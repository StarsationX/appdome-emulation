.class public Lruntime/loading/ContentProviderHooks;
.super Ljava/lang/Object;


# static fields
.field private static onCreateHookCalled:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/4 v0, 0x0

    sput-boolean v0, Lruntime/loading/ContentProviderHooks;->onCreateHookCalled:Z

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static onCreateHook(Landroid/content/ContentProvider;)V
    .locals 1

    sget-boolean v0, Lruntime/loading/ContentProviderHooks;->onCreateHookCalled:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    sput-boolean v0, Lruntime/loading/ContentProviderHooks;->onCreateHookCalled:Z

    invoke-virtual {p0}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    invoke-static {p0}, Lruntime/loading/StaticCalls;->dynamicInit(Landroid/content/Context;)V

    return-void
.end method

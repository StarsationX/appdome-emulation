.class Lruntime/loading/InjectedActivity$2;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lruntime/loading/InjectedActivity;->ADShowPopup(Ljava/lang/String;Ljava/lang/String;ZZZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$message:Lruntime/loading/InjectedActivity$MessageOutput;


# direct methods
.method constructor <init>(Lruntime/loading/InjectedActivity$MessageOutput;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    iput-object p1, p0, Lruntime/loading/InjectedActivity$2;->val$message:Lruntime/loading/InjectedActivity$MessageOutput;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    invoke-static {}, Lruntime/loading/InjectedActivity;->-$$Nest$sfgetg1h2i3j4k5l6m7n8o9p0()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lruntime/loading/InjectedActivity$2;->val$message:Lruntime/loading/InjectedActivity$MessageOutput;

    iget-boolean v0, v0, Lruntime/loading/InjectedActivity$MessageOutput;->y1z2a3b4c5d6e7f8g9h0:Z

    if-eqz v0, :cond_1

    iget-object v0, p0, Lruntime/loading/InjectedActivity$2;->val$message:Lruntime/loading/InjectedActivity$MessageOutput;

    invoke-static {v0}, Lruntime/loading/InjectedActivity;->-$$Nest$smhandleExitToast(Lruntime/loading/InjectedActivity$MessageOutput;)V

    goto :goto_0

    :cond_1
    :try_start_0
    invoke-static {}, Lruntime/loading/InjectedActivity;->-$$Nest$sfgeta1b2c3d4e5f6g7h8i9j0k1()Ljava/util/Stack;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Stack;->size()I

    move-result v0

    const-string v1, "set_toast_stack_capacity"

    const/16 v2, 0x14

    invoke-static {v1, v2}, Lruntime/ADConfig/ADConfig;->getInt(Ljava/lang/String;I)I

    move-result v1

    if-gt v0, v1, :cond_2

    iget-object v0, p0, Lruntime/loading/InjectedActivity$2;->val$message:Lruntime/loading/InjectedActivity$MessageOutput;

    invoke-static {v0}, Lruntime/loading/InjectedActivity;->-$$Nest$smshowToast(Lruntime/loading/InjectedActivity$MessageOutput;)Landroid/widget/Toast;

    move-result-object v0

    invoke-static {}, Lruntime/loading/InjectedActivity;->-$$Nest$sfgeta1b2c3d4e5f6g7h8i9j0k1()Ljava/util/Stack;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/util/Stack;->push(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_2
    goto :goto_0

    :catch_0
    move-exception v0

    :goto_0
    return-void
.end method

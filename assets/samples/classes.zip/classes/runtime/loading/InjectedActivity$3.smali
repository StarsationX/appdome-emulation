.class Lruntime/loading/InjectedActivity$3;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lruntime/loading/InjectedActivity;->handleExitToast(Lruntime/loading/InjectedActivity$MessageOutput;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$exitToast:Lruntime/loading/InjectedActivity$MessageOutput;


# direct methods
.method constructor <init>(Lruntime/loading/InjectedActivity$MessageOutput;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    iput-object p1, p0, Lruntime/loading/InjectedActivity$3;->val$exitToast:Lruntime/loading/InjectedActivity$MessageOutput;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    invoke-static {}, Lruntime/ContextSaver;->get()Landroid/content/Context;

    move-result-object v0

    iget-object v1, p0, Lruntime/loading/InjectedActivity$3;->val$exitToast:Lruntime/loading/InjectedActivity$MessageOutput;

    iget-boolean v1, v1, Lruntime/loading/InjectedActivity$MessageOutput;->i1j2k3l4m5n6o7p8q9r0:Z

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-static {v0, v1}, Lruntime/loading/InjectedActivity;->-$$Nest$smdie(Landroid/content/Context;Ljava/lang/Boolean;)V

    return-void
.end method

.class public final synthetic Lruntime/Strings/StringIndexer-IA;
.super Ljava/lang/Object;

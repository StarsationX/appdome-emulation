.class Lruntime/Strings/StringIndexer$stringIndexerHolder;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lruntime/Strings/StringIndexer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "aRHKQ7"
.end annotation


# static fields
.field private static final globalVariableInstance:Lruntime/Strings/StringIndexer;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lruntime/Strings/StringIndexer;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lruntime/Strings/StringIndexer;-><init>(Lruntime/Strings/StringIndexer-IA;)V

    sput-object v0, Lruntime/Strings/StringIndexer$stringIndexerHolder;->globalVariableInstance:Lruntime/Strings/StringIndexer;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static getInstance()Lruntime/Strings/StringIndexer;
    .locals 1

    sget-object v0, Lruntime/Strings/StringIndexer$stringIndexerHolder;->globalVariableInstance:Lruntime/Strings/StringIndexer;

    return-object v0
.end method

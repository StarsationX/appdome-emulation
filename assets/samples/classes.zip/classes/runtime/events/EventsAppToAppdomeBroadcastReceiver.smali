.class public interface abstract Lruntime/events/EventsAppToAppdomeBroadcastReceiver;
.super Ljava/lang/Object;


# direct methods
.method public static onReceive(Landroid/content/Intent;)V
    .locals 0

    return-void
.end method

.class public Lruntime/events/Orientation;
.super Ljava/lang/Object;


# static fields
.field private static accelerometer:Landroid/hardware/Sensor;

.field public static deviceFaceDown:Z

.field private static listener:Landroid/hardware/SensorEventListener;

.field private static sensorManager:Landroid/hardware/SensorManager;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/4 v0, 0x0

    sput-boolean v0, Lruntime/events/Orientation;->deviceFaceDown:Z

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static getDeviceFaceDown()Z
    .locals 1

    sget-boolean v0, Lruntime/events/Orientation;->deviceFaceDown:Z

    return v0
.end method

.method public static register(Landroid/content/Context;)V
    .locals 3

    const-string v0, "RHk"

    invoke-static/range {v0 .. v0}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/hardware/SensorManager;

    sput-object p0, Lruntime/events/Orientation;->sensorManager:Landroid/hardware/SensorManager;

    sget-object p0, Lruntime/events/Orientation;->sensorManager:Landroid/hardware/SensorManager;

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/hardware/SensorManager;->getDefaultSensor(I)Landroid/hardware/Sensor;

    move-result-object p0

    sput-object p0, Lruntime/events/Orientation;->accelerometer:Landroid/hardware/Sensor;

    sget-object p0, Lruntime/events/Orientation;->accelerometer:Landroid/hardware/Sensor;

    if-eqz p0, :cond_0

    new-instance p0, Lruntime/events/Orientation$1;

    invoke-direct {p0}, Lruntime/events/Orientation$1;-><init>()V

    sput-object p0, Lruntime/events/Orientation;->listener:Landroid/hardware/SensorEventListener;

    sget-object p0, Lruntime/events/Orientation;->sensorManager:Landroid/hardware/SensorManager;

    sget-object v0, Lruntime/events/Orientation;->listener:Landroid/hardware/SensorEventListener;

    sget-object v1, Lruntime/events/Orientation;->accelerometer:Landroid/hardware/Sensor;

    const/4 v2, 0x3

    invoke-virtual {p0, v0, v1, v2}, Landroid/hardware/SensorManager;->registerListener(Landroid/hardware/SensorEventListener;Landroid/hardware/Sensor;I)Z

    :cond_0
    return-void
.end method

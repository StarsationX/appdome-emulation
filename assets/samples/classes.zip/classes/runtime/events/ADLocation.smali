.class public Lruntime/events/ADLocation;
.super Landroid/app/Service;

# interfaces
.implements Landroid/location/LocationListener;


# static fields
.field private static final MIN_DISTANCE_CHANGE_FOR_UPDATES:J = 0xaL

.field private static final MIN_TIME_BW_UPDATES:J = 0xea60L

.field private static instance:Lruntime/events/ADLocation;


# instance fields
.field private location:Landroid/location/Location;

.field protected locationManager:Landroid/location/LocationManager;

.field private locationState:Ljava/lang/String;

.field private wifiSSIDStatus:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$m_getLocation(Lruntime/events/ADLocation;)V
    .locals 0

    invoke-direct {p0}, Lruntime/events/ADLocation;->_getLocation()V

    return-void
.end method

.method private constructor <init>()V
    .locals 1

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    const-string v0, "RHs"

    invoke-static/range {v0 .. v0}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lruntime/events/ADLocation;->locationState:Ljava/lang/String;

    const-string v0, "RHq"

    invoke-static/range {v0 .. v0}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lruntime/events/ADLocation;->wifiSSIDStatus:Ljava/lang/String;

    return-void
.end method

.method private requestLocationUpdates(Ljava/lang/String;)V
    .locals 7

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lruntime/events/ADLocation;->locationManager:Landroid/location/LocationManager;

    if-eqz v0, :cond_0

    iget-object v1, p0, Lruntime/events/ADLocation;->locationManager:Landroid/location/LocationManager;

    const-wide/32 v3, 0xea60

    const/high16 v5, 0x41200000    # 10.0f

    move-object v2, p1

    move-object v6, p0

    invoke-virtual/range {v1 .. v6}, Landroid/location/LocationManager;->requestLocationUpdates(Ljava/lang/String;JFLandroid/location/LocationListener;)V

    const-string v0, "RHL"

    invoke-static/range {v0 .. v0}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lruntime/events/ADLocation;->locationState:Ljava/lang/String;

    const-string v0, "RHc"

    invoke-static/range {v0 .. v0}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lruntime/events/ADLocation;->wifiSSIDStatus:Ljava/lang/String;

    iget-object v0, p0, Lruntime/events/ADLocation;->locationManager:Landroid/location/LocationManager;

    invoke-virtual {v0, p1}, Landroid/location/LocationManager;->getLastKnownLocation(Ljava/lang/String;)Landroid/location/Location;

    move-result-object p1

    if-eqz p1, :cond_0

    iput-object p1, p0, Lruntime/events/ADLocation;->location:Landroid/location/Location;

    :cond_0
    return-void
.end method

.method public static getLatitude()D
    .locals 2

    invoke-static {}, Lruntime/events/ADLocation;->getInstance()Lruntime/events/ADLocation;

    move-result-object v0

    invoke-virtual {v0}, Lruntime/events/ADLocation;->_getLatitude()D

    move-result-wide v0

    return-wide v0
.end method

.method private _getLocation()V
    .locals 5

    const-string v0, "RHr"

    invoke-static/range {v0 .. v0}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "RHp"

    invoke-static/range {v1 .. v1}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    :try_start_0
    invoke-static {}, Lruntime/ContextSaver;->get()Landroid/content/Context;

    move-result-object v2

    const-string v3, "location"

    invoke-virtual {v2, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/location/LocationManager;

    iput-object v2, p0, Lruntime/events/ADLocation;->locationManager:Landroid/location/LocationManager;

    iget-object v2, p0, Lruntime/events/ADLocation;->locationManager:Landroid/location/LocationManager;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const-string v3, "RHm"

    invoke-static/range {v3 .. v3}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "RHT"

    invoke-static/range {v4 .. v4}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    if-nez v2, :cond_0

    :try_start_1
    iput-object v4, p0, Lruntime/events/ADLocation;->locationState:Ljava/lang/String;

    iput-object v3, p0, Lruntime/events/ADLocation;->wifiSSIDStatus:Ljava/lang/String;

    return-void

    :cond_0
    iget-object v2, p0, Lruntime/events/ADLocation;->locationManager:Landroid/location/LocationManager;

    invoke-virtual {v2, v1}, Landroid/location/LocationManager;->isProviderEnabled(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-direct {p0, v1}, Lruntime/events/ADLocation;->requestLocationUpdates(Ljava/lang/String;)V

    :cond_1
    iget-object v2, p0, Lruntime/events/ADLocation;->locationManager:Landroid/location/LocationManager;

    invoke-virtual {v2, v0}, Landroid/location/LocationManager;->isProviderEnabled(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-direct {p0, v0}, Lruntime/events/ADLocation;->requestLocationUpdates(Ljava/lang/String;)V

    :cond_2
    iget-object v2, p0, Lruntime/events/ADLocation;->locationManager:Landroid/location/LocationManager;

    invoke-virtual {v2, v0}, Landroid/location/LocationManager;->isProviderEnabled(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_4

    iget-object v0, p0, Lruntime/events/ADLocation;->locationManager:Landroid/location/LocationManager;

    invoke-virtual {v0, v1}, Landroid/location/LocationManager;->isProviderEnabled(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_3

    goto :goto_0

    :cond_3
    goto :goto_1

    :cond_4
    :goto_0
    iput-object v4, p0, Lruntime/events/ADLocation;->locationState:Ljava/lang/String;

    iput-object v3, p0, Lruntime/events/ADLocation;->wifiSSIDStatus:Ljava/lang/String;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    return-void

    :catch_0
    move-exception v0

    const-string v0, "RHj"

    invoke-static/range {v0 .. v0}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lruntime/events/ADLocation;->locationState:Ljava/lang/String;

    const-string v0, "RHw"

    invoke-static/range {v0 .. v0}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lruntime/events/ADLocation;->wifiSSIDStatus:Ljava/lang/String;

    :goto_1
    return-void
.end method

.method public static getWifiSsid()Ljava/lang/String;
    .locals 1

    invoke-static {}, Lruntime/events/ADLocation;->getInstance()Lruntime/events/ADLocation;

    move-result-object v0

    invoke-virtual {v0}, Lruntime/events/ADLocation;->getSsid()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static getInstance()Lruntime/events/ADLocation;
    .locals 1

    sget-object v0, Lruntime/events/ADLocation;->instance:Lruntime/events/ADLocation;

    if-nez v0, :cond_0

    new-instance v0, Lruntime/events/ADLocation;

    invoke-direct {v0}, Lruntime/events/ADLocation;-><init>()V

    sput-object v0, Lruntime/events/ADLocation;->instance:Lruntime/events/ADLocation;

    :cond_0
    sget-object v0, Lruntime/events/ADLocation;->instance:Lruntime/events/ADLocation;

    return-object v0
.end method

.method public static getState()Ljava/lang/String;
    .locals 1

    invoke-static {}, Lruntime/events/ADLocation;->getInstance()Lruntime/events/ADLocation;

    move-result-object v0

    iget-object v0, v0, Lruntime/events/ADLocation;->locationState:Ljava/lang/String;

    return-object v0
.end method

.method public static getWifiSSIDStatusMessage()Ljava/lang/String;
    .locals 1

    invoke-static {}, Lruntime/events/ADLocation;->getInstance()Lruntime/events/ADLocation;

    move-result-object v0

    iget-object v0, v0, Lruntime/events/ADLocation;->wifiSSIDStatus:Ljava/lang/String;

    return-object v0
.end method

.method public static getLongitude()D
    .locals 2

    invoke-static {}, Lruntime/events/ADLocation;->getInstance()Lruntime/events/ADLocation;

    move-result-object v0

    invoke-virtual {v0}, Lruntime/events/ADLocation;->_getLongitude()D

    move-result-wide v0

    return-wide v0
.end method


# virtual methods
.method public _getLatitude()D
    .locals 2

    iget-object v0, p0, Lruntime/events/ADLocation;->location:Landroid/location/Location;

    if-nez v0, :cond_0

    invoke-virtual {p0}, Lruntime/events/ADLocation;->getLocation()V

    :cond_0
    iget-object v0, p0, Lruntime/events/ADLocation;->location:Landroid/location/Location;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lruntime/events/ADLocation;->location:Landroid/location/Location;

    invoke-virtual {v0}, Landroid/location/Location;->getLatitude()D

    move-result-wide v0

    return-wide v0

    :cond_1
    invoke-static {}, Lruntime/ContextSaver;->get()Landroid/content/Context;

    move-result-object v0

    const-string v1, "RHD"

    invoke-static/range {v1 .. v1}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/Context;->checkCallingOrSelfPermission(Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_2

    const-string v0, "RHg"

    invoke-static/range {v0 .. v0}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lruntime/events/ADLocation;->locationState:Ljava/lang/String;

    :cond_2
    const-wide/16 v0, 0x0

    return-wide v0
.end method

.method public _getLongitude()D
    .locals 2

    iget-object v0, p0, Lruntime/events/ADLocation;->location:Landroid/location/Location;

    if-nez v0, :cond_0

    invoke-virtual {p0}, Lruntime/events/ADLocation;->getLocation()V

    :cond_0
    iget-object v0, p0, Lruntime/events/ADLocation;->location:Landroid/location/Location;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lruntime/events/ADLocation;->location:Landroid/location/Location;

    invoke-virtual {v0}, Landroid/location/Location;->getLongitude()D

    move-result-wide v0

    return-wide v0

    :cond_1
    invoke-static {}, Lruntime/ContextSaver;->get()Landroid/content/Context;

    move-result-object v0

    const-string v1, "RH0"

    invoke-static/range {v1 .. v1}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/Context;->checkCallingOrSelfPermission(Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_2

    const-string v0, "RHS"

    invoke-static/range {v0 .. v0}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lruntime/events/ADLocation;->locationState:Ljava/lang/String;

    :cond_2
    const-wide/16 v0, 0x0

    return-wide v0
.end method

.method public getLocation()V
    .locals 3

    invoke-static {}, Lruntime/ContextSaver;->get()Landroid/content/Context;

    move-result-object v0

    const-string v1, "RHV"

    invoke-static/range {v1 .. v1}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/Context;->checkCallingOrSelfPermission(Ljava/lang/String;)I

    move-result v0

    const/4 v1, -0x1

    if-ne v0, v1, :cond_0

    invoke-static {}, Lruntime/ContextSaver;->get()Landroid/content/Context;

    move-result-object v0

    const-string v2, "RH9"

    invoke-static/range {v2 .. v2}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/content/Context;->checkCallingOrSelfPermission(Ljava/lang/String;)I

    move-result v0

    if-ne v0, v1, :cond_0

    const-string v0, "RHU"

    invoke-static/range {v0 .. v0}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lruntime/events/ADLocation;->locationState:Ljava/lang/String;

    const-string v0, "RHn"

    invoke-static/range {v0 .. v0}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lruntime/events/ADLocation;->wifiSSIDStatus:Ljava/lang/String;

    return-void

    :cond_0
    const-string v0, "RHy"

    invoke-static/range {v0 .. v0}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lruntime/events/ADLocation;->locationState:Ljava/lang/String;

    const-string v0, "RHI"

    invoke-static/range {v0 .. v0}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lruntime/events/ADLocation;->wifiSSIDStatus:Ljava/lang/String;

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Lruntime/ContextSaver;->get()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v1, Lruntime/events/ADLocation$1;

    invoke-direct {v1, p0}, Lruntime/events/ADLocation$1;-><init>(Lruntime/events/ADLocation;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public getSsid()Ljava/lang/String;
    .locals 5

    const-string v0, "RHM"

    invoke-static/range {v0 .. v0}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :try_start_0
    invoke-static {}, Lruntime/ContextSaver;->get()Landroid/content/Context;

    move-result-object v1

    const-string v2, "wifi"

    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/net/wifi/WifiManager;

    invoke-virtual {v1}, Landroid/net/wifi/WifiManager;->getConnectionInfo()Landroid/net/wifi/WifiInfo;

    move-result-object v1

    invoke-virtual {v1}, Landroid/net/wifi/WifiInfo;->getNetworkId()I

    move-result v2

    const/4 v3, -0x1

    if-ne v2, v3, :cond_1

    const-string v2, "Location services enabled no wifi connection"

    iput-object v2, p0, Lruntime/events/ADLocation;->wifiSSIDStatus:Ljava/lang/String;

    invoke-static {}, Lruntime/ContextSaver;->get()Landroid/content/Context;

    move-result-object v2

    const-string v4, "android.permission.ACCESS_FINE_LOCATION"

    invoke-virtual {v2, v4}, Landroid/content/Context;->checkCallingOrSelfPermission(Ljava/lang/String;)I

    move-result v2

    if-ne v2, v3, :cond_0

    invoke-static {}, Lruntime/ContextSaver;->get()Landroid/content/Context;

    move-result-object v2

    const-string v4, "android.permission.ACCESS_COARSE_LOCATION"

    invoke-virtual {v2, v4}, Landroid/content/Context;->checkCallingOrSelfPermission(Ljava/lang/String;)I

    move-result v2

    if-ne v2, v3, :cond_0

    const-string v2, "This application is not authorized to use location services cant get WifiSsid"

    iput-object v2, p0, Lruntime/events/ADLocation;->wifiSSIDStatus:Ljava/lang/String;

    goto :goto_0

    :cond_0
    iget-object v2, p0, Lruntime/events/ADLocation;->locationManager:Landroid/location/LocationManager;

    if-eqz v2, :cond_1

    iget-object v2, p0, Lruntime/events/ADLocation;->locationManager:Landroid/location/LocationManager;

    const-string v3, "gps"

    invoke-virtual {v2, v3}, Landroid/location/LocationManager;->isProviderEnabled(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_1

    const-string v2, "Location Services is disable cant get WifiSsid"

    iput-object v2, p0, Lruntime/events/ADLocation;->wifiSSIDStatus:Ljava/lang/String;

    :cond_1
    :goto_0
    invoke-virtual {v1}, Landroid/net/wifi/WifiInfo;->getSSID()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1}, Landroid/net/wifi/WifiInfo;->getSSID()Ljava/lang/String;

    move-result-object v1

    const-string v3, "<unknown ssid>"

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz v1, :cond_2

    goto :goto_1

    :cond_2
    move-object v0, v2

    :goto_1
    return-object v0

    :catch_0
    move-exception v1

    return-object v0
.end method

.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public onLocationChanged(Landroid/location/Location;)V
    .locals 0

    iput-object p1, p0, Lruntime/events/ADLocation;->location:Landroid/location/Location;

    return-void
.end method

.method public onProviderDisabled(Ljava/lang/String;)V
    .locals 0

    invoke-virtual {p0}, Lruntime/events/ADLocation;->getLocation()V

    return-void
.end method

.method public onProviderEnabled(Ljava/lang/String;)V
    .locals 0

    invoke-virtual {p0}, Lruntime/events/ADLocation;->getLocation()V

    return-void
.end method

.method public onStatusChanged(Ljava/lang/String;ILandroid/os/Bundle;)V
    .locals 0

    invoke-virtual {p0}, Lruntime/events/ADLocation;->getLocation()V

    return-void
.end method

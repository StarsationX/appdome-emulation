.class public Lruntime/events/EventRegistrator;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lruntime/events/EventRegistrator$EventRegistratorListener;
    }
.end annotation


# static fields
.field private static cachedSupportedDevEvents:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field private static devEventsPermission:Ljava/lang/String;

.field private static eventListeners:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Lruntime/events/EventRegistrator$EventRegistratorListener;",
            ">;"
        }
    .end annotation
.end field

.field private static registeredNamesToReceivers:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Landroid/content/BroadcastReceiver;",
            ">;>;"
        }
    .end annotation
.end field

.field private static registeredReceiversToNames:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Landroid/content/BroadcastReceiver;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation
.end field

.field private static s_eventsReceiver:Landroid/content/BroadcastReceiver;


# direct methods
.method static bridge synthetic -$$Nest$sfgeteventListeners()Ljava/util/HashMap;
    .locals 1

    sget-object v0, Lruntime/events/EventRegistrator;->eventListeners:Ljava/util/HashMap;

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 2

    const/4 v0, 0x0

    sput-object v0, Lruntime/events/EventRegistrator;->s_eventsReceiver:Landroid/content/BroadcastReceiver;

    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    sput-object v1, Lruntime/events/EventRegistrator;->eventListeners:Ljava/util/HashMap;

    new-instance v1, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v1}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    sput-object v1, Lruntime/events/EventRegistrator;->registeredReceiversToNames:Ljava/util/Map;

    new-instance v1, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v1}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    sput-object v1, Lruntime/events/EventRegistrator;->registeredNamesToReceivers:Ljava/util/Map;

    sput-object v0, Lruntime/events/EventRegistrator;->devEventsPermission:Ljava/lang/String;

    sput-object v0, Lruntime/events/EventRegistrator;->cachedSupportedDevEvents:Ljava/util/Map;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static registerToEventInternal(Ljava/lang/String;Lruntime/events/EventRegistrator$EventRegistratorListener;)V
    .locals 1

    const/4 v0, 0x0

    invoke-static {p0, p1, v0}, Lruntime/events/EventRegistrator;->registerToEvent(Ljava/lang/String;Lruntime/events/EventRegistrator$EventRegistratorListener;Z)V

    return-void
.end method

.method public static registerToEvent(Ljava/lang/String;)V
    .locals 1

    const/4 v0, 0x0

    invoke-static {p0, v0}, Lruntime/events/EventRegistrator;->registerToEvent(Ljava/lang/String;Lruntime/events/EventRegistrator$EventRegistratorListener;)V

    return-void
.end method

.method public static registerToEvent(Ljava/lang/String;Lruntime/events/EventRegistrator$EventRegistratorListener;)V
    .locals 1

    const/4 v0, 0x1

    invoke-static {p0, p1, v0}, Lruntime/events/EventRegistrator;->registerToEvent(Ljava/lang/String;Lruntime/events/EventRegistrator$EventRegistratorListener;Z)V

    return-void
.end method

.method private static declared-synchronized registerToEvent(Ljava/lang/String;Lruntime/events/EventRegistrator$EventRegistratorListener;Z)V
    .locals 1

    const-class p2, Lruntime/events/EventRegistrator;

    monitor-enter p2

    :try_start_0
    invoke-static {p0}, Lruntime/loading/NativeBridge;->getExternalEventID(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v0, :cond_0

    monitor-exit p2

    return-void

    :cond_0
    :try_start_1
    invoke-static {p0}, Lruntime/events/EventRegistrator;->registerLocalBroadcastReceivers(Ljava/lang/String;)V

    invoke-static {p0}, Lruntime/loading/NativeBridge;->appRegisteredToEvent(Ljava/lang/String;)V

    sget-object v0, Lruntime/events/EventRegistrator;->eventListeners:Ljava/util/HashMap;

    invoke-virtual {v0, p0, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p2

    return-void

    :catchall_0
    move-exception p0

    monitor-exit p2

    throw p0
.end method

.method private static applicationRegisteredToEvent(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V
    .locals 2

    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p1}, Landroid/content/IntentFilter;->countActions()I

    move-result v1

    if-ge v0, v1, :cond_0

    invoke-virtual {p1, v0}, Landroid/content/IntentFilter;->getAction(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lruntime/events/EventRegistrator;->registerLocalBroadcastReceivers(Ljava/lang/String;)V

    invoke-static {p0, v1}, Lruntime/events/EventRegistrator;->addToRegisteredReceivers(Landroid/content/BroadcastReceiver;Ljava/lang/String;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public static callRegisterReceiver(Ljava/lang/Object;Ljava/lang/reflect/Method;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V
    .locals 1
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    filled-new-array {p2, p3}, [Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p1, p0, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {p2, p3}, Lruntime/events/EventRegistrator;->applicationRegisteredToEvent(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V

    return-void
.end method

.method public static registerReceiverV4(Ljava/lang/Object;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V
    .locals 7

    const-string v0, "RHH"

    invoke-static/range {v0 .. v0}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    :try_start_0
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v4

    new-array v5, v1, [Ljava/lang/Class;

    const-class v6, Landroid/content/BroadcastReceiver;

    aput-object v6, v5, v3

    const-class v6, Landroid/content/IntentFilter;

    aput-object v6, v5, v2

    invoke-virtual {v4, v0, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v4

    invoke-static {p0, v4, p1, p2}, Lruntime/events/EventRegistrator;->callRegisterReceiver(Ljava/lang/Object;Ljava/lang/reflect/Method;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p0

    invoke-static {p0, v3}, Lruntime/Reflections;->handleReflectionException(Ljava/lang/Exception;Z)V

    goto :goto_1

    :catch_1
    move-exception v4

    :try_start_1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v4

    new-array v1, v1, [Ljava/lang/Class;

    const-class v5, Landroid/content/BroadcastReceiver;

    aput-object v5, v1, v3

    const-class v5, Landroid/content/IntentFilter;

    aput-object v5, v1, v2

    invoke-virtual {v4, v0, v1}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/reflect/Method;->setAccessible(Z)V

    invoke-static {p0, v0, p1, p2}, Lruntime/events/EventRegistrator;->callRegisterReceiver(Ljava/lang/Object;Ljava/lang/reflect/Method;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2

    goto :goto_0

    :catch_2
    move-exception p0

    invoke-static {p0, v3}, Lruntime/Reflections;->handleReflectionException(Ljava/lang/Exception;Z)V

    :goto_0
    nop

    :goto_1
    return-void
.end method

.method public static shouldSwizzle(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Z
    .locals 1

    const/4 p0, 0x0

    if-eqz p1, :cond_0

    invoke-static {p1}, Lruntime/events/EventRegistrator;->intentFilterContainsActions(Landroid/content/IntentFilter;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p1, p0}, Landroid/content/IntentFilter;->getAction(I)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lruntime/loading/NativeBridge;->supportsDevEvent(Ljava/lang/String;)Z

    move-result p0

    return p0

    :cond_0
    return p0
.end method

.method public static registerTrackedRecieverWithDevEventPermission(Ljava/lang/Object;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Landroid/os/Handler;Ljava/lang/String;)Landroid/content/Intent;
    .locals 6

    nop

    const/4 v5, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    :try_start_0
    invoke-static/range {v0 .. v5}, Lruntime/events/EventRegistrator;->registerTrackedRecieverWithDevEventPermission(Ljava/lang/Object;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Landroid/os/Handler;Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    const/4 p1, 0x0

    invoke-static {p0, p1}, Lruntime/Reflections;->handleReflectionException(Ljava/lang/Exception;Z)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static registerTrackedRecieverWithDevEventPermission(Ljava/lang/Object;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Landroid/os/Handler;Ljava/lang/String;I)Landroid/content/Intent;
    .locals 7

    const/4 p5, 0x0

    :try_start_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x21

    if-lt v0, v1, :cond_0

    const/4 v0, 0x4

    move v6, v0

    goto :goto_0

    :cond_0
    move v6, p5

    :goto_0
    invoke-static {}, Lruntime/events/EventRegistrator;->getDeveventsPermission()Ljava/lang/String;

    move-result-object v4

    move-object v1, p0

    check-cast v1, Landroid/content/Context;

    move-object v2, p1

    move-object v3, p2

    move-object v5, p3

    invoke-virtual/range {v1 .. v6}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;I)Landroid/content/Intent;

    move-result-object p0

    invoke-static {p1, p4}, Lruntime/events/EventRegistrator;->applicationRegisteredToEventWithAction(Landroid/content/BroadcastReceiver;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    invoke-static {p0, p5}, Lruntime/Reflections;->handleReflectionException(Ljava/lang/Exception;Z)V

    const/4 p0, 0x0

    return-object p0
.end method

.method private static declared-synchronized addEventToRegisteredNames(Landroid/content/BroadcastReceiver;Ljava/lang/String;)V
    .locals 3

    const-class v0, Lruntime/events/EventRegistrator;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lruntime/events/EventRegistrator;->registeredNamesToReceivers:Ljava/util/Map;

    invoke-interface {v1, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    new-instance v1, Ljava/util/LinkedList;

    invoke-direct {v1}, Ljava/util/LinkedList;-><init>()V

    sget-object v2, Lruntime/events/EventRegistrator;->registeredNamesToReceivers:Ljava/util/Map;

    invoke-interface {v2, p1, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    sget-object v1, Lruntime/events/EventRegistrator;->registeredNamesToReceivers:Ljava/util/Map;

    invoke-interface {v1, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/List;

    invoke-interface {p1, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    monitor-exit v0

    throw p0
.end method

.method public static intentFilterContainsActions(Landroid/content/IntentFilter;)Z
    .locals 0

    invoke-virtual {p0}, Landroid/content/IntentFilter;->countActions()I

    move-result p0

    if-lez p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method private static registerDevEvents(Ljava/lang/Object;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Landroid/os/Handler;I)Landroid/content/IntentFilter;
    .locals 11

    new-instance v0, Landroid/content/IntentFilter;

    invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V

    invoke-virtual {p2}, Landroid/content/IntentFilter;->countActions()I

    move-result v1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    invoke-virtual {p2}, Landroid/content/IntentFilter;->countActions()I

    move-result v4

    if-ge v3, v4, :cond_0

    invoke-virtual {p2, v3}, Landroid/content/IntentFilter;->getAction(I)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v1, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    invoke-static {v1}, Lruntime/events/EventRegistrator;->supportsDevEvents([Ljava/lang/String;)[Z

    move-result-object v3

    nop

    :goto_1
    array-length v4, v3

    if-ge v2, v4, :cond_3

    aget-boolean v4, v3, v2

    if-eqz v4, :cond_2

    if-nez p4, :cond_1

    aget-object v4, v1, v2

    invoke-static {p0, p1, p2, p3, v4}, Lruntime/events/EventRegistrator;->registerTrackedRecieverWithDevEventPermission(Ljava/lang/Object;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Landroid/os/Handler;Ljava/lang/String;)Landroid/content/Intent;

    goto :goto_2

    :cond_1
    aget-object v9, v1, v2

    move-object v5, p0

    move-object v6, p1

    move-object v7, p2

    move-object v8, p3

    move v10, p4

    invoke-static/range {v5 .. v10}, Lruntime/events/EventRegistrator;->registerTrackedRecieverWithDevEventPermission(Ljava/lang/Object;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Landroid/os/Handler;Ljava/lang/String;I)Landroid/content/Intent;

    goto :goto_2

    :cond_2
    aget-object v4, v1, v2

    invoke-virtual {v0, v4}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    :goto_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_3
    return-object v0
.end method

.method private static applicationRegisteredToEventWithAction(Landroid/content/BroadcastReceiver;Ljava/lang/String;)V
    .locals 0

    invoke-static {p1}, Lruntime/events/EventRegistrator;->registerLocalBroadcastReceivers(Ljava/lang/String;)V

    invoke-static {p0, p1}, Lruntime/events/EventRegistrator;->addToRegisteredReceivers(Landroid/content/BroadcastReceiver;Ljava/lang/String;)V

    return-void
.end method

.method public static getDeveventsPermission()Ljava/lang/String;
    .locals 2

    sget-object v0, Lruntime/events/EventRegistrator;->devEventsPermission:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {}, Lruntime/loading/NativeBridge;->getApplicationIDAppdome()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "RHQ"

    invoke-static/range {v1 .. v1}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "RHl"

    invoke-static/range {v1 .. v1}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v0}, Lruntime/ADConfig/ADConfig;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lruntime/events/EventRegistrator;->devEventsPermission:Ljava/lang/String;

    :cond_0
    sget-object v0, Lruntime/events/EventRegistrator;->devEventsPermission:Ljava/lang/String;

    return-object v0
.end method

.method public static final getUserIdGlobalString()Ljava/lang/String;
    .locals 1

    const-string v0, "RHu"

    invoke-static/range {v0 .. v0}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static declared-synchronized unregisterReceiverInternal(Ljava/lang/Object;Landroid/content/BroadcastReceiver;)V
    .locals 7

    const-class v0, Lruntime/events/EventRegistrator;

    monitor-enter v0

    const/4 v1, 0x0

    :try_start_0
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const-string v3, "unregisterReceiver"

    const/4 v4, 0x1

    new-array v5, v4, [Ljava/lang/Class;

    const-class v6, Landroid/content/BroadcastReceiver;

    aput-object v6, v5, v1

    invoke-virtual {v2, v3, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, p0, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p0, Lruntime/events/EventRegistrator;->registeredReceiversToNames:Ljava/util/Map;

    invoke-interface {p0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/List;

    if-eqz p0, :cond_1

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v2

    if-lez v2, :cond_1

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    sget-object v3, Lruntime/events/EventRegistrator;->registeredNamesToReceivers:Ljava/util/Map;

    invoke-interface {v3, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    sget-object v3, Lruntime/events/EventRegistrator;->registeredNamesToReceivers:Ljava/util/Map;

    invoke-interface {v3, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/List;

    invoke-interface {v3, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    if-ge v3, v4, :cond_0

    sget-object v3, Lruntime/events/EventRegistrator;->registeredNamesToReceivers:Ljava/util/Map;

    invoke-interface {v3, v2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {v2}, Lruntime/events/EventRegistrator;->applicationUnregisteredFromEvent(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    goto :goto_0

    :cond_1
    goto :goto_1

    :catchall_0
    move-exception p0

    goto :goto_2

    :catch_0
    move-exception p0

    :try_start_1
    invoke-static {p0, v1}, Lruntime/Reflections;->handleReflectionException(Ljava/lang/Exception;Z)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_1
    monitor-exit v0

    return-void

    :goto_2
    monitor-exit v0

    throw p0
.end method

.method public static registerLocalBroadcastReceiver(Ljava/lang/String;Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V
    .locals 5

    :try_start_0
    invoke-static {p0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p0

    const-string v0, "getInstance"

    const/4 v1, 0x1

    new-array v2, v1, [Ljava/lang/Class;

    const-class v3, Landroid/content/Context;

    const/4 v4, 0x0

    aput-object v3, v2, v4

    invoke-virtual {p0, v0, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    invoke-virtual {v0, v2, p1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const-string v0, "registerReceiver"

    const/4 v2, 0x2

    new-array v2, v2, [Ljava/lang/Class;

    const-class v3, Landroid/content/BroadcastReceiver;

    aput-object v3, v2, v4

    const-class v3, Landroid/content/IntentFilter;

    aput-object v3, v2, v1

    invoke-virtual {p0, v0, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p0

    filled-new-array {p2, p3}, [Ljava/lang/Object;

    move-result-object p2

    invoke-virtual {p0, p1, p2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p0

    :goto_0
    return-void
.end method

.method private static initReceiverIfNeeded()V
    .locals 1

    sget-object v0, Lruntime/events/EventRegistrator;->s_eventsReceiver:Landroid/content/BroadcastReceiver;

    if-eqz v0, :cond_0

    return-void

    :cond_0
    new-instance v0, Lruntime/events/EventRegistrator$1;

    invoke-direct {v0}, Lruntime/events/EventRegistrator$1;-><init>()V

    sput-object v0, Lruntime/events/EventRegistrator;->s_eventsReceiver:Landroid/content/BroadcastReceiver;

    return-void
.end method

.method private static applicationUnregisteredFromEvent(Ljava/lang/String;)V
    .locals 0

    invoke-static {p0}, Lruntime/loading/NativeBridge;->appUnRegisteredFromEvent(Ljava/lang/String;)V

    return-void
.end method

.method private static declared-synchronized addToRegisteredReceivers(Landroid/content/BroadcastReceiver;Ljava/lang/String;)V
    .locals 3

    const-class v0, Lruntime/events/EventRegistrator;

    monitor-enter v0

    :try_start_0
    invoke-static {p1}, Lruntime/loading/NativeBridge;->appRegisteredToEvent(Ljava/lang/String;)V

    sget-object v1, Lruntime/events/EventRegistrator;->registeredReceiversToNames:Ljava/util/Map;

    invoke-interface {v1, p0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    new-instance v1, Ljava/util/LinkedList;

    invoke-direct {v1}, Ljava/util/LinkedList;-><init>()V

    sget-object v2, Lruntime/events/EventRegistrator;->registeredReceiversToNames:Ljava/util/Map;

    invoke-interface {v2, p0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    sget-object v1, Lruntime/events/EventRegistrator;->registeredReceiversToNames:Ljava/util/Map;

    invoke-interface {v1, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    invoke-interface {v1, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-static {p0, p1}, Lruntime/events/EventRegistrator;->addEventToRegisteredNames(Landroid/content/BroadcastReceiver;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    monitor-exit v0

    throw p0
.end method

.method public static registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;
    .locals 1

    const/4 v0, 0x0

    if-nez p1, :cond_0

    return-object v0

    :cond_0
    if-nez p0, :cond_1

    return-object v0

    :cond_1
    invoke-static {}, Lruntime/ContextSaver;->get()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p0, p1}, Lruntime/events/EventRegistrator;->registerReceiver(Ljava/lang/Object;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    move-result-object p0

    return-object p0
.end method

.method public static registerReceiver(Ljava/lang/Object;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;
    .locals 3

    const/4 v0, 0x0

    const/4 v1, 0x0

    :try_start_0
    invoke-static {p0, p1, p2, v1, v0}, Lruntime/events/EventRegistrator;->registerDevEvents(Ljava/lang/Object;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Landroid/os/Handler;I)Landroid/content/IntentFilter;

    move-result-object p2

    invoke-virtual {p2}, Landroid/content/IntentFilter;->countActions()I

    move-result v2

    if-lez v2, :cond_0

    check-cast p0, Landroid/content/Context;

    invoke-virtual {p0, p1, p2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :cond_0
    goto :goto_0

    :catch_0
    move-exception p0

    invoke-static {p0, v0}, Lruntime/Reflections;->handleReflectionException(Ljava/lang/Exception;Z)V

    :goto_0
    return-object v1
.end method

.method public static registerReceiver(Ljava/lang/Object;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;
    .locals 2

    nop

    const/4 v0, 0x0

    :try_start_0
    invoke-static {p0, p1, p2, v0, p3}, Lruntime/events/EventRegistrator;->registerDevEvents(Ljava/lang/Object;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Landroid/os/Handler;I)Landroid/content/IntentFilter;

    move-result-object p2

    invoke-virtual {p2}, Landroid/content/IntentFilter;->countActions()I

    move-result v1

    if-lez v1, :cond_0

    check-cast p0, Landroid/content/Context;

    invoke-virtual {p0, p1, p2, p3}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :cond_0
    goto :goto_0

    :catch_0
    move-exception p0

    const/4 p1, 0x0

    invoke-static {p0, p1}, Lruntime/Reflections;->handleReflectionException(Ljava/lang/Exception;Z)V

    :goto_0
    return-object v0
.end method

.method public static registerReceiver(Ljava/lang/Object;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;)Landroid/content/Intent;
    .locals 2

    const/4 v0, 0x0

    :try_start_0
    invoke-static {p0, p1, p2, p4, v0}, Lruntime/events/EventRegistrator;->registerDevEvents(Ljava/lang/Object;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Landroid/os/Handler;I)Landroid/content/IntentFilter;

    move-result-object p2

    invoke-virtual {p2}, Landroid/content/IntentFilter;->countActions()I

    move-result v1

    if-lez v1, :cond_0

    check-cast p0, Landroid/content/Context;

    invoke-virtual {p0, p1, p2, p3, p4}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;)Landroid/content/Intent;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :cond_0
    goto :goto_0

    :catch_0
    move-exception p0

    invoke-static {p0, v0}, Lruntime/Reflections;->handleReflectionException(Ljava/lang/Exception;Z)V

    :goto_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public static registerReceiver(Ljava/lang/Object;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;I)Landroid/content/Intent;
    .locals 6

    nop

    :try_start_0
    invoke-static {p0, p1, p2, p4, p5}, Lruntime/events/EventRegistrator;->registerDevEvents(Ljava/lang/Object;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Landroid/os/Handler;I)Landroid/content/IntentFilter;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/IntentFilter;->countActions()I

    move-result p2

    if-lez p2, :cond_0

    move-object v0, p0

    check-cast v0, Landroid/content/Context;

    move-object v1, p1

    move-object v3, p3

    move-object v4, p4

    move v5, p5

    invoke-virtual/range {v0 .. v5}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;I)Landroid/content/Intent;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :cond_0
    goto :goto_0

    :catch_0
    move-exception p0

    const/4 p1, 0x0

    invoke-static {p0, p1}, Lruntime/Reflections;->handleReflectionException(Ljava/lang/Exception;Z)V

    :goto_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public static registerLocalBroadcastReceivers(Ljava/lang/String;)V
    .locals 8

    invoke-static {}, Lruntime/events/EventRegistrator;->initReceiverIfNeeded()V

    invoke-static {}, Lruntime/ContextSaver;->get()Landroid/content/Context;

    move-result-object v6

    if-nez v6, :cond_0

    return-void

    :cond_0
    sget-object v0, Lruntime/events/EventRegistrator;->eventListeners:Ljava/util/HashMap;

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    new-instance v7, Landroid/content/IntentFilter;

    invoke-direct {v7, p0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x21

    if-lt p0, v0, :cond_1

    sget-object v1, Lruntime/events/EventRegistrator;->s_eventsReceiver:Landroid/content/BroadcastReceiver;

    invoke-static {}, Lruntime/events/EventRegistrator;->getDeveventsPermission()Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    const/4 v5, 0x4

    move-object v0, v6

    move-object v2, v7

    invoke-virtual/range {v0 .. v5}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;I)Landroid/content/Intent;

    goto :goto_0

    :cond_1
    sget-object p0, Lruntime/events/EventRegistrator;->s_eventsReceiver:Landroid/content/BroadcastReceiver;

    invoke-static {}, Lruntime/events/EventRegistrator;->getDeveventsPermission()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v6, p0, v7, v0, v1}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;)Landroid/content/Intent;

    :goto_0
    nop

    sget-object p0, Lruntime/events/EventRegistrator;->s_eventsReceiver:Landroid/content/BroadcastReceiver;

    const-string v0, "RHW"

    invoke-static/range {v0 .. v0}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v6, p0, v7}, Lruntime/events/EventRegistrator;->registerLocalBroadcastReceiver(Ljava/lang/String;Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V

    nop

    sget-object p0, Lruntime/events/EventRegistrator;->s_eventsReceiver:Landroid/content/BroadcastReceiver;

    const-string v0, "RHJ"

    invoke-static/range {v0 .. v0}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v6, p0, v7}, Lruntime/events/EventRegistrator;->registerLocalBroadcastReceiver(Ljava/lang/String;Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V

    :cond_2
    return-void
.end method

.method public static unregisterReceiver(Ljava/lang/Object;Landroid/content/BroadcastReceiver;)V
    .locals 0

    invoke-static {p0, p1}, Lruntime/events/EventRegistrator;->unregisterReceiverInternal(Ljava/lang/Object;Landroid/content/BroadcastReceiver;)V

    return-void
.end method

.method private static final supportsDevEvents([Ljava/lang/String;)[Z
    .locals 7

    const-class v0, Lruntime/events/EventRegistrator;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lruntime/events/EventRegistrator;->cachedSupportedDevEvents:Ljava/util/Map;

    const/4 v2, 0x0

    if-nez v1, :cond_1

    const-string v1, "-689270382,1348870940,1348870940,1348870940,1348870940,1348870940,2135452663,454995754,-1548264220,444591453,419416377,-1579759283,866846000,-525629780,-1817151780,750213889,1226290077,119160091,784249101,1165571966,45,-1074211648,181627525,107929857,469304517,1082177239,651869767,-1332943053"

    const-string v3, ","

    invoke-virtual {v1, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    new-instance v3, Ljava/util/HashMap;

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    move v4, v2

    :goto_0
    array-length v5, v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-ge v4, v5, :cond_0

    :try_start_1
    aget-object v5, v1, v4

    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v6, 0x1

    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v6

    invoke-interface {v3, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_1

    :catch_0
    move-exception v5

    :goto_1
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_0
    :try_start_2
    sput-object v3, Lruntime/events/EventRegistrator;->cachedSupportedDevEvents:Ljava/util/Map;

    :cond_1
    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    array-length v0, p0

    new-array v0, v0, [Z

    nop

    :goto_2
    array-length v1, p0

    if-ge v2, v1, :cond_2

    sget-object v1, Lruntime/events/EventRegistrator;->cachedSupportedDevEvents:Ljava/util/Map;

    aget-object v3, p0, v2

    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v1, v3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    aput-boolean v1, v0, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_2
    return-object v0

    :catchall_0
    move-exception p0

    :try_start_3
    monitor-exit v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    throw p0
.end method

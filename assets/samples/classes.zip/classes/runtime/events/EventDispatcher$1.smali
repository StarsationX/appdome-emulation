.class Lruntime/events/EventDispatcher$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lruntime/events/EventDispatcher;->doDispatch(Ljava/lang/String;Landroid/os/Bundle;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$context:Landroid/content/Context;

.field final synthetic val$intent:Landroid/content/Intent;


# direct methods
.method constructor <init>(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    iput-object p1, p0, Lruntime/events/EventDispatcher$1;->val$context:Landroid/content/Context;

    iput-object p2, p0, Lruntime/events/EventDispatcher$1;->val$intent:Landroid/content/Intent;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    nop

    iget-object v0, p0, Lruntime/events/EventDispatcher$1;->val$context:Landroid/content/Context;

    iget-object v1, p0, Lruntime/events/EventDispatcher$1;->val$intent:Landroid/content/Intent;

    const-string v2, "RHz"

    invoke-static/range {v2 .. v2}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v0, v1}, Lruntime/events/EventDispatcher;->disptachToLocalBroadcastReceiver(Ljava/lang/String;Landroid/content/Context;Landroid/content/Intent;)V

    nop

    iget-object v0, p0, Lruntime/events/EventDispatcher$1;->val$context:Landroid/content/Context;

    iget-object v1, p0, Lruntime/events/EventDispatcher$1;->val$intent:Landroid/content/Intent;

    const-string v2, "RH5"

    invoke-static/range {v2 .. v2}, Lruntime/Strings/StringIndexer;->_getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v0, v1}, Lruntime/events/EventDispatcher;->disptachToLocalBroadcastReceiver(Ljava/lang/String;Landroid/content/Context;Landroid/content/Intent;)V

    return-void
.end method

.class public interface abstract Lruntime/events/EventRegistrator$EventRegistratorListener;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lruntime/events/EventRegistrator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "eIYJQ4"
.end annotation


# virtual methods
.method public abstract OnEventReceived(Landroid/os/Bundle;)V
.end method

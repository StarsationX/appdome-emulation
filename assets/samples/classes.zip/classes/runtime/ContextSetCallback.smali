.class public interface abstract Lruntime/ContextSetCallback;
.super Ljava/lang/Object;


# virtual methods
.method public abstract onContextSet()V
.end method
